const config = {
	version: 0,
	wp_endpoint: "https://fl1digital.com/wp-json/wp/v2/",
	woo_endpoint: "https://fl1digital.com/wp-json/wc/v2/",
	woo_key:
		"ck_47c11621051625a03e51c24d4770fe1539fee7eb",
	woo_secret:
		"cs_376e156d8a5454df4c936246b69b2016dafdc0fb",
};

export default config;
